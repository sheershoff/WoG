@extends('admin.app')


@section('content')
  <h1 class="page-header">Магазин</h1>
@stop

@section('script')
	{{-- expr --}}
@stop