@extends('admin.app')


@section('content')
  <h1 class="page-header">Скилы</h1>
@stop

@section('script')
	{{-- expr --}}
@stop