<html lang="ru-RU">
<head>
    <meta charset="text/html">
</head>
<body>
    Subject: {{$title}}
    Message body:
    {{$body}}
</body>
</html>