<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1472628400249" ID="ID_105415148" MODIFIED="1472628447554" TEXT="&#x41f;&#x435;&#x440;&#x432;&#x44b;&#x439; &#x432;&#x445;&#x43e;&#x434;">
<node CREATED="1472628459602" ID="ID_889201243" MODIFIED="1472629244456" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <i>Role=-2</i>
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1472628477525" ID="ID_68525364" MODIFIED="1472629275037" TEXT="Quest=0 &#x43f;&#x43e;&#x43b;&#x443;&#x447;&#x438; &#x438;&#x43d;&#x432;&#x430;&#x439;&#x442;">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1472628738760" ID="ID_980721600" MODIFIED="1472629041458" TEXT="11. welcome">
<icon BUILTIN="full-1"/>
</node>
<node CREATED="1472628755625" ID="ID_979268213" MODIFIED="1472629044057" TEXT="12. FindInvite">
<icon BUILTIN="full-2"/>
</node>
<node CREATED="1472628790010" ID="ID_1473420866" MODIFIED="1472629060899" TEXT="13. OpenInvite">
<icon BUILTIN="full-3"/>
<icon BUILTIN="full-4"/>
<node CREATED="1472628803412" ID="ID_451991874" MODIFIED="1472629303483">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <i>upRole=1</i>
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
</map>
