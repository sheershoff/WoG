<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1472283847631" ID="ID_440000873" MODIFIED="1472283861151" TEXT="&#x41f;&#x435;&#x440;&#x441;&#x43e;&#x43d;&#x430;&#x436;">
<node CREATED="1472283872455" ID="ID_432332220" MODIFIED="1472283883951" POSITION="right" TEXT="&#x422;&#x438;&#x442;&#x443;&#x43b;">
<node CREATED="1472283889414" ID="ID_138174898" MODIFIED="1472283897224" TEXT="&#x440;&#x430;&#x437;&#x43d;&#x43e;&#x441;&#x447;&#x438;&#x446;&#x430; &#x441;&#x43f;&#x43b;&#x435;&#x442;&#x435;&#x43d;"/>
<node CREATED="1472283897991" ID="ID_207880199" MODIFIED="1472283906041" TEXT="&#x43c;&#x430;&#x441;&#x442;&#x435;&#x440; - &#x437;&#x43e;&#x43b;&#x43e;&#x442;&#x44b;&#x435; &#x440;&#x443;&#x43a;&#x438;"/>
<node CREATED="1472287230105" ID="ID_1741452553" MODIFIED="1472287235702" TEXT="&#x41e;&#x445;&#x43e;&#x442;&#x43d;&#x438;&#x43a;"/>
</node>
<node CREATED="1472283885344" ID="ID_893734895" MODIFIED="1472283887531" POSITION="right" TEXT="&#x431;&#x430;&#x444;&#x444;&#x44b;">
<node CREATED="1472287414145" ID="ID_1659340354" MODIFIED="1472287418069" TEXT="&#x41c;&#x430;&#x43a;&#x441;&#x438;&#x43c;&#x430;&#x43b;&#x44c;&#x43d;&#x44b;&#x439; &#x440;&#x430;&#x43d;&#x433; - &#x420;&#x430;&#x437;&#x443;&#x43c;+&#x412;&#x43e;&#x43b;&#x44f;/4"/>
</node>
</node>
</map>
