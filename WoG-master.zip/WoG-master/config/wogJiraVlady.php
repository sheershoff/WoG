<?php

return [

    /*
      |--------------------------------------------------------------------------
      | Default Organization
      |--------------------------------------------------------------------------
      |
      |
     */

    'apiurl' => env('JIRAVLADYAPIURL', ''),
    'username' => env('JIRAVLADYUSERNAME', ''),
    'password' => env('JIRAVLADYPASSWORD', ''),
    'proxy' => env('PROXY', ''),
];
