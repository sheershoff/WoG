cd ..
./vendor/bin/phpunit